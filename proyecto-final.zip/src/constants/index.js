export const Status = {
  ACTIVE: 'active',
  INACTIVE: 'inactive',
};